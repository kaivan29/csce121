/*HW1PR1
Section - 306
Name - Kaivan Shah*/
#include "std_lib_facilities_3.h"
int main()//C++ programs start by executing the function main
{
	 cout<<"\n CROSSWORD \n"; // output CROSSWORD
	 cout<<"\n ACROSS";// output ACROSS

	 cout<<"\n 1.To explain any statement in the code after token //";
	 cout<<"\n 3.The program that links the other program together";
 	 cout<<"\n 5.A statement of the exact meaning of a word";
	 cout<<"\n 7.Counter of the if statement";
	 cout<<"\n 9.Repetition of a series of elements of a data structure";
	 cout<<"\n11.Process of joining two strings";
 	 cout<<"\n13.A group of statements that together perform a task";
	 cout<<"\n15.Process uses operator and operand";

	 cout<<"\n\n DOWN";//To print the clues of the words DOWN

	 cout<<"\n 2.Machine that translates the program code";
	 cout<<"\n 4.To access in-built library";
 	 cout<<"\n 8.Program statement specifying how a piece of code can be used";
	 cout<<"\n 10.Sequence of elements that one can access by an index";
 	 cout<<"\n 12.Unary operators that add one from their operand";
	 cout<<"\n 14.Antonym of begin()";

	 cout<<"\n******************************************************";
	 cout<<"\n\n SOLUTION \n\n";//To print the SOLUTION of the crossword

	 cout<<"\n                          12.  14.  \n";
	 cout<<"                           I    E   \n";
	 cout<<"       2.             13.FUNCTION   \n";
	 cout<<"       C                   C    D   \n";
	 cout<<"   1.COMMENT               R    ()  \n";
	 cout<<"       M                 7.ELSE     \n";
	 cout<<" 4.I   P     8.D    10.    M        \n";
	 cout<<"   N   I       E     V     E        \n";
	 cout<<"   C   L    11.CONCATENATION        \n";
	 cout<<" 3.LINKER      L     C     T        \n"; 
	 cout<<"   U   R       A     T              \n";
	 cout<<"   D      6.   R  9.LOOP            \n";
	 cout<<"5.DEFINATION   A     R              \n";
	 cout<<"          B    T                    \n";
	 cout<<"          J    I                    \n";
	 cout<<"     15.OPERATION                   \n";
	 cout<<"          C    N                    \n";
	 cout<<"          T                         \n";
}
